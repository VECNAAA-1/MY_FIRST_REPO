package org.example;

import org.example.auth.AuthService;
import org.example.dao.StudentDAO;
import org.example.dao.ResultDAO;
import org.example.dao.impl.StudentDAOImpl;
import org.example.dao.impl.ResultDAOImpl;
import org.example.model.Student;
import org.example.model.Result;

import java.util.List;
import java.util.Scanner;

public class Main {
    private static final Scanner sc = new Scanner(System.in);
    private static final StudentDAO studentDAO = new StudentDAOImpl();
    private static final ResultDAO resultDAO = new ResultDAOImpl();

    public static void main(String[] args) {
        System.out.println("=== Student Result Management System ===");
        if (!authenticate()) {
            System.out.println("Authentication failed. Exiting.");
            return;
        }

        while (true) {
            menu();
            int choice = readInt("Choose: ");
            try {
                switch (choice) {
                    case 1:
                        addStudent();
                        break;
                    case 2:
                        updateStudent();
                        break;
                    case 3:
                        viewAllStudents();
                        break;
                    case 4:
                        addResult();
                        break;
                    case 5:
                        updateResult();
                        break;
                    case 6:
                        viewResultsByStudent();
                        break;
                    case 7:
                        deleteStudent();
                        break;
                    case 8:
                        deleteResult();
                        break;
                    case 9:
                        return;
                    default:
                        System.out.println("Invalid choice.");
                }

            } catch (Exception e) {
                System.err.println("Error: " + e.getMessage());
                e.printStackTrace(System.err);
            }
        }
    }

    private static boolean authenticate() {
        System.out.print("Username: ");
        String u = sc.nextLine().trim();
        System.out.print("Password: ");
        String p = sc.nextLine().trim();
        return AuthService.login(u, p);
    }

    private static void menu() {
        System.out.println("\n--- Menu ---");
        System.out.println("1. Add Student");
        System.out.println("2. Update Student");
        System.out.println("3. View All Students");
        System.out.println("4. Add Result");
        System.out.println("5. Update Result");
        System.out.println("6. View Results by StudentId");
        System.out.println("7. Delete Student");
        System.out.println("8. Delete Result");
        System.out.println("9. Exit");
    }

    private static void addStudent() throws Exception {
        System.out.println("Add Student:");
        String name = readString("Name: ");
        String course = readString("Course: ");
        String email = readString("Email: ");
        String phone = readString("Phone: ");
        Student s = new Student(name, course, email, phone);
        int id = studentDAO.addStudent(s);
        System.out.println("Added student with id: " + id);
    }

    private static void updateStudent() throws Exception {
        int id = readInt("StudentId to update: ");
        Student existing = studentDAO.getStudentById(id);
        if (existing == null) {
            System.out.println("Student not found.");
            return;
        }
        String name = readStringDefault("Name ("+existing.getName()+"): ", existing.getName());
        String course = readStringDefault("Course ("+existing.getCourse()+"): ", existing.getCourse());
        String email = readStringDefault("Email ("+existing.getEmail()+"): ", existing.getEmail());
        String phone = readStringDefault("Phone ("+existing.getPhone()+"): ", existing.getPhone());
        existing.setName(name);
        existing.setCourse(course);
        existing.setEmail(email);
        existing.setPhone(phone);
        boolean ok = studentDAO.updateStudent(existing);
        System.out.println(ok ? "Updated." : "Update failed.");
    }

    private static void viewAllStudents() throws Exception {
        List<Student> list = studentDAO.getAllStudents();
        if (list.isEmpty()) {
            System.out.println("No students found.");
            return;
        }
        for (Student s : list) System.out.println(s);
    }

    private static void addResult() throws Exception {
        int studentId = readInt("StudentId: ");
        Student s = studentDAO.getStudentById(studentId);
        if (s == null) {
            System.out.println("Student not found.");
            return;
        }
        int marks = readInt("Marks (0-100): ");
        Result r = new Result(studentId, marks, ""); // grade will be computed
        int resultId = resultDAO.addResult(r);
        System.out.println("Result added with id: " + resultId);
    }

    private static void updateResult() throws Exception {
        int resultId = readInt("ResultId to update: ");
        Result existing = resultDAO.getResultById(resultId);
        if (existing == null) {
            System.out.println("Result not found.");
            return;
        }
        int marks = readInt("New marks (" + existing.getMarks() + "): ");
        existing.setMarks(marks);
        boolean ok = resultDAO.updateResult(existing);
        System.out.println(ok ? "Result updated." : "Update failed.");
    }

    private static void viewResultsByStudent() throws Exception {
        int studentId = readInt("StudentId: ");
        Student s = studentDAO.getStudentById(studentId);
        if (s == null) {
            System.out.println("Student not found.");
            return;
        }
        List<Result> list = resultDAO.getResultsByStudentId(studentId);
        if (list.isEmpty()) {
            System.out.println("No results found for student " + studentId);
            return;
        }
        System.out.println("Results for " + s.getName() + ":");
        for (Result r : list) System.out.println(r);
    }

    private static void deleteStudent() throws Exception {
        int id = readInt("StudentId to delete: ");
        boolean ok = studentDAO.deleteStudent(id);
        System.out.println(ok ? "Student deleted." : "Delete failed (maybe FK constraint or not exists).");
    }

    private static void deleteResult() throws Exception {
        int id = readInt("ResultId to delete: ");
        boolean ok = resultDAO.deleteResult(id);
        System.out.println(ok ? "Result deleted." : "Delete failed.");
    }

    // helpers
    private static int readInt(String prompt) {
        while (true) {
            System.out.print(prompt);
            try {
                String line = sc.nextLine().trim();
                return Integer.parseInt(line);
            } catch (NumberFormatException e) {
                System.out.println("Enter a valid integer.");
            }
        }
    }

    private static String readString(String prompt) {
        System.out.print(prompt);
        return sc.nextLine().trim();
    }

    private static String readStringDefault(String prompt, String def) {
        System.out.print(prompt);
        String line = sc.nextLine().trim();
        return line.isEmpty() ? def : line;
    }
}
