package org.example.dao;

import org.example.model.Result;
import java.util.List;

public interface ResultDAO {
    int addResult(Result r) throws Exception;
    boolean updateResult(Result r) throws Exception;
    List<Result> getResultsByStudentId(int studentId) throws Exception;
    Result getResultById(int resultId) throws Exception;
    boolean deleteResult(int resultId) throws Exception;
}
