package org.example.dao.impl;

import org.example.dao.ResultDAO;
import org.example.model.Result;
import org.example.util.JDBCUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ResultDAOImpl implements ResultDAO {

    private String calculateGrade(int marks) {
        if (marks >= 80) return "A";
        if (marks >= 60) return "B";
        if (marks >= 40) return "C";
        return "F";
    }

    @Override
    public int addResult(Result r) throws Exception {
        String sql = "INSERT INTO results (studentId, marks, grade) VALUES (?, ?, ?)";
        String grade = calculateGrade(r.getMarks());
        try (Connection conn = JDBCUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, r.getStudentId());
            ps.setInt(2, r.getMarks());
            ps.setString(3, grade);
            int affected = ps.executeUpdate();
            if (affected == 0) return -1;
            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) return rs.getInt(1);
            }
            return -1;
        }
    }

    @Override
    public boolean updateResult(Result r) throws Exception {
        String sql = "UPDATE results SET marks=?, grade=? WHERE resultId=?";
        String grade = calculateGrade(r.getMarks());
        try (Connection conn = JDBCUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, r.getMarks());
            ps.setString(2, grade);
            ps.setInt(3, r.getResultId());
            return ps.executeUpdate() > 0;
        }
    }

    @Override
    public List<Result> getResultsByStudentId(int studentId) throws Exception {
        String sql = "SELECT resultId, studentId, marks, grade FROM results WHERE studentId=? ORDER BY resultId";
        List<Result> list = new ArrayList<>();
        try (Connection conn = JDBCUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, studentId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Result r = new Result(
                            rs.getInt("resultId"),
                            rs.getInt("studentId"),
                            rs.getInt("marks"),
                            rs.getString("grade"));
                    list.add(r);
                }
            }
        }
        return list;
    }

    @Override
    public Result getResultById(int resultId) throws Exception {
        String sql = "SELECT resultId, studentId, marks, grade FROM results WHERE resultId=?";
        try (Connection conn = JDBCUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, resultId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return new Result(
                            rs.getInt("resultId"),
                            rs.getInt("studentId"),
                            rs.getInt("marks"),
                            rs.getString("grade"));
                }
            }
        }
        return null;
    }

    @Override
    public boolean deleteResult(int resultId) throws Exception {
        String sql = "DELETE FROM results WHERE resultId=?";
        try (Connection conn = JDBCUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, resultId);
            return ps.executeUpdate() > 0;
        }
    }
}
