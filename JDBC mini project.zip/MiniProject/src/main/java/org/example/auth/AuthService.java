package org.example.auth;

public class AuthService {
    // simple hardcoded credentials
    private static final String USER = "root";
    private static final String PASS = "Mayankhenry*123";

    public static boolean login(String username, String password) {
        return USER.equals(username) && PASS.equals(password);
    }
}
